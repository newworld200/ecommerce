
import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore';
import {getStorage} from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyCHG7IUC2wKExwQzDP5CSsTtfsIKwYI21U",
  authDomain: "maltimart-9f850.firebaseapp.com",
  projectId: "maltimart-9f850",
  storageBucket: "maltimart-9f850.appspot.com",
  messagingSenderId: "216799268478",
  appId: "1:216799268478:web:8aa744faecd4bddeb1d22f"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;