import React from 'react'
import {Col, Container, Row} from 'react-bootstrap'
import useGetData from '../custom-hooks/useGetData';

import { db } from '../firebaseConfig';
import {doc, deleteDoc} from 'firebase/firestore'

function Users() {

    const {data: usersData} = useGetData('users')

    const deleteUser = async(id) => {
        await deleteDoc(doc(db, 'users', id))
        alert('user deleted!')
      }

  return (
    <section>
        <Container>
            <Row>
                <Col lg='12'>
                    <h4 className='fw-bold'>Users</h4>
                </Col>
                <Col lg='12' className='pt-5'>
                    <table className='table pt-5'>
                        <thead>
                            <tr>
                                <th>Images</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {
                                usersData?.map(user => (
                                    <tr key={user.uid}>
                                        <td><img src={user.photoURL} alt='' /></td>
                                        <td>{user.displayName}</td>
                                        <td>{user.email}</td>
                                        <td><button onClick={() => deleteUser(user.uid)} className='btn btn-danger'>Delete</button></td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                </Col>
            </Row>
        </Container>
    </section>
  )
}

export default Users