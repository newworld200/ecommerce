import React, { useRef } from 'react'
import { Container, Row } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import logo from '../assets/images/eco-logo.png'
import userIcon from '../assets/images/user-icon.png';
import { useSelector } from 'react-redux';


const nav_links =[
    {
        path:'home',
        display:'Home'
    },
    {
        path:'shop',
        display:'Shop'
    },
    {
        path:'cart',
        display:'Cart'
    },

]


function NewHeader() {

    const totalQuantity = useSelector((state) => state.cart.totalQuantity)


    const menuRef = useRef(null);

    const menuToggle = () => menuRef.current.classList.toggle('active_menu');

  return (
    <header className='header'>
        <Container>
            <Row>
                <div className='nav_wrapper'>
                    <div className='logo'>
                        <img src={logo} alt='' />
                        <div>
                            <h1>Multimart</h1>
                        </div>
                    </div>

                    <div className='navigation' ref={menuRef} onClick={menuToggle}>
                    <ul className='menu'>
                            {
                                nav_links.map((item, index )=> (
                                    <li className='nav_item' key={index}>
                                    <NavLink to={item.path} className={(navClass) => navClass.isActive ? 'nav_active' : ''}>{item.display}</NavLink>
                                </li>
                                ))
                            }
                        </ul>
                    </div>

                    <div className='nav_icons'>
                    <span className='fav_icon'>
                       <i class="ri-heart-line"></i>
                        </span>
                        <span className='cart_icon'>
                        <i class="ri-shopping-bag-line"></i>
                        <span className='badge'>{totalQuantity}</span>
                        </span>
                        <span><img src={userIcon} alt='' /></span>
                    </div>

                    <div className='mobile_menu'>
                        <span onClick={menuToggle}><i class="ri-menu-line"></i></span>
                    </div>

                </div>
            </Row>
        </Container>
    </header>
  )
}

export default NewHeader


// import React from 'react'
// import { Link, useNavigate } from 'react-router-dom'
// import { signOut } from 'firebase/auth';
// import { auth } from '../firebaseConfig';
// import { toast } from 'react-toastify';

// import { useSelector } from 'react-redux';

 

// function NewHeader() {
//     const navigate =useNavigate();

//     const totalQuantity = useSelector((state) => state.cart.totalQuantity)


//     const logout = () => {
//         signOut(auth).then(() => {
//             toast.success('logged out')
//             navigate('/login');
//         }).catch (
//             err => {
//                 toast.error(err.message)
//             }
//         )
//     }

//   return (
//     <div style={{display:"flex", justifyContent:'space-around'}}>
//         <div>
//             <h1>Logo</h1>
//         </div>
//         <nav>
//             <ul style={{display:"flex"}}>
//                 <li style={{padding:"10px", backgroundColor:"black", color:"white"}}><Link to="/home">Home</Link></li>
//                 <li style={{padding:"10px", backgroundColor:"black", color:"white"}}><Link to="/shop">Shop</Link></li>
//                 <li style={{padding:"10px", backgroundColor:"black", color:"white"}}><Link to="/cart">Cart</Link></li>
//             </ul>
//         </nav>

//         <div style={{display:'flex', justifyContent:'center'}}>
//             <h3><Link to='/dashboard'>Dashboard</Link></h3>
//             <h3 onClick={logout}>Logout</h3>
//             <h3><Link to='/login'>Login</Link></h3>
//             <h3><span className='fav_icon'><i class="ri-shopping-bag-line"></i>
//                         {totalQuantity}
//                         </span></h3>
//         </div>
//     </div>
//   )
// }

// export default NewHeader