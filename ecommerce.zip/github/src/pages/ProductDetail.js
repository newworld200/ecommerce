import React, { useState } from 'react'
import './ProductDetail.css'
import { Col, Container, Row } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import Helmet from '../components/Helmet';
import CommonSection from '../components/Products/CommonSection';
import products from '../assets/data/products';
import { motion } from 'framer-motion';

function ProductDetail() {
  const [tab, setTab] = useState('desc')

  const {id} = useParams()
  const product = products.find(item => item.id === id)

  const {imgUrl, productName, price, avgRating, shortDesc, reviews, description} = product

  return (
    <div>
      <Helmet>
        <CommonSection />
        <section className='pt-0'>
          <Container>
            <Row>
              <Col lg='6'>
                <img src={imgUrl} alt='' />
              </Col>
              <Col lg='6'>
                <div className='product_details'>
                  <h2>{productName}</h2>
                  <div className='product_rating d-flex align-items-center gap-5 mb-4'>
                    <div>
                      <span>
                        <i class='ri-star-s-fill'></i>
                        <i class='ri-star-s-fill'></i>
                        <i class='ri-star-s-fill'></i>
                        <i class='ri-star-s-fill'></i>
                        <i class='ri-star-half-s-line'></i>
                      </span>
                    </div>
                    <p>({avgRating} ratings)</p>
                 </div>
                 <span className='product_price'>${price}</span>
                 <p className="mt-3">{shortDesc}</p>

                 <motion.button whileTap={{scale:1.2}} className='buy_btn'>Add to Cart</motion.button>
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section>
          <Container>
            <Row>
              <Col lang='12'>
                <div className='tab_wrapper d-flex align-items-center gap-5'>
                  <h6 className={`${tab === 'desc' ? 'active_tab' : ''}`} onClick={() => setTab('desc')}>Description</h6>
                  <h6 className={`${tab === 'rev' ? 'active_tab' : ''}`} onClick={() => setTab('rev')}>Review {reviews.length}</h6>
                </div>
                {
                  tab === 'desc' ? (
                    <div className='tab_content mt-5'>
                  <p>{description}</p>
                </div>
                  ) : (
                    <div className='product_review mt-5'>
                      <div className='review_wrapper'>
                        <ul>
                          {
                            reviews?.map((item, index) => (
                              <li key={index} className='mb-4'>
                                <span>{item.rating} (rating) </span>
                              <p>{item.text}</p></li>
                            ))
                          }
                        </ul>

                        <div className='review_form'>
                          <h4>Leave Your Experience</h4>
                          <form action="">
                            <div className='form_group'>
                              <input type ='text' placeholder="Enter Name" />
                            </div>
                            <div className='form_group'>
                              <span>
                                1<i class="ri-star-s-fill"></i>
                                2<i class="ri-star-s-fill"></i>
                                3<i class="ri-star-s-fill"></i>
                                4<i class="ri-star-s-fill"></i>
                                5<i class="ri-star-s-fill"></i>
                              </span>
                            </div>

                            <div className='form_group'>
                              <textarea rows={4} type ='text' placeholder="Review Message" />
                            </div>

                          </form>
                        </div>


                      </div>
                    </div>
                  )
                }

                
              </Col>
            </Row>
          </Container>
        </section>
      </Helmet>
    </div>
  )
}

export default ProductDetail