import React from 'react'
import CommonSection from '../components/Products/CommonSection';
import Helmet from '../components/Helmet';

function Shop() {
  return (
    <div>
      <Helmet title='Shop'>
        <CommonSection title='Products' />
      </Helmet>
    </div>
  )
}

export default Shop