import React from 'react'
import { Outlet } from 'react-router-dom'
import AdminNav from '../admin/AdminNav'
// import { Navigate } from 'react-router-dom'
// import Dashboard from '../admin/Dashboard'
// import Dashboard from '../admin/Dashboard'
// import Login from '../pages/Login'

function ProtectedRoute() {
  return (
    <div>
      <AdminNav />
    {/* <Dashboard /> */}
    <Outlet />
    </div>
  )
}

export default ProtectedRoute