import React from 'react'
import './App.css';
import Cart from './pages/Cart'
import { Route, Routes } from 'react-router-dom'
// import NewHeader from './NewComponents/NewHeader';
import NewShop from './NewComponents/NewShop';
import ProductDetail from './pages/ProductDetail';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import Signup from './pages/Signup';
// import Home from './pages/Home';
import Dashboard from './admin/Dashboard';
import AllProducts from './admin/AllProducts'
import AddProducts from './admin/AddProducts'
import ProtectedRoute from './routers/ProtectedRoute';
import NewHome from './NewComponents/NewHome';
import Users from './admin/Users';
// import ProtectedRoute from './routers/ProtectedRoute';

function New() {
  return (
    <div>
        <Routes>
           <Route path="/" element={<NewHome />} />
             <Route path='shop' element={<NewShop /> } />
             <Route path='shop/:id' element={<ProductDetail /> } />
             <Route path='cart' element={<Cart /> } />
             <Route path='checkout' element={<Checkout /> } />
             <Route path='login' element={<Login /> } />
             <Route path='signup' element={<Signup /> } />
             <Route path='dashboard' element={<Dashboard /> } />

             <Route path='/*' element ={<ProtectedRoute />}>
               <Route path='dashboard/all-products' element={<AllProducts/>} />
               <Route path='dashboard/add-product' element={<AddProducts/>} />
               <Route path='dashboard/users' element={<Users />} />
               <Route path='dashboard' element={<Dashboard />} />
             </Route>



        </Routes>
    </div>
  )
}

export default New