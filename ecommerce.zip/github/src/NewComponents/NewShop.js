import React, { useState } from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import CommonSection from '../components/Products/CommonSection';
import '../pages/Shop.css'

import products from '../assets/data/products'
import ProductList from '../components/ProductList';

function NewShop() {

    const [productsData, setProductsData] =useState(products);

    const handleFilter = e => {
        const filterValue = e.target.value

        if(filterValue === 'sofa') {
            const filteredProducts = products.filter(
                (item) => item.category === 'sofa'
            )

            setProductsData(filteredProducts)
        }

        if(filterValue === 'mobile') {
            const filteredProducts = products.filter(
                (item) => item.category === 'mobile'
            )

            setProductsData(filteredProducts)
        }

        if(filterValue === 'chair') {
            const filteredProducts = products.filter(
                (item) => item.category === 'chair'
            )

            setProductsData(filteredProducts)
        }
    }

    const handleSearch = e => {

        const searchTerm = e.target.value

        const searchedProduct = products.filter(item => item.productName.toLowerCase().includes(searchTerm.toLowerCase()))

        setProductsData(searchedProduct)
    }
  return (
    <div>
        <CommonSection title="Products" />

        <section>
            <Container>
                <Row>
                    <Col lg='3' md='3'>
                        <div className='filter_widget'>
                            <select onChange={handleFilter}>
                                <option>Filter by Category</option>
                                <option value="sofa">sofa</option>
                                <option value="mobile">mobile</option>
                                <option value="chair">Chair</option>
                                <option value="watch">Watch</option>
                                <option value="wireless">wireless</option>
                            </select>
                        </div>
                    </Col>
                    <Col lg="3" md='3'>
                    <div className='filter_widget'>
                            <select>
                                <option>Filter by Category</option>
                                <option value="ascending">Ascending</option>
                                <option value="descending">Descending</option>
                            </select>
                        </div>
                    </Col>
                    <Col lg="6" md="6">
                        <div className='search_box'>
                            <input type='text' placeholder='Search.....'  onChange={handleSearch}/>
                            <span>
                                <i class='ri-search-line'></i>
                            </span>
                        </div>
                    </Col>
                </Row>
            </Container>
        </section>

        <section>
            <Container>
                <Row>
                    {
                        productsData.length === 0 ? ( <h1 className='text-center'>No Products are found</h1>) :
                        (<ProductList data={productsData} />)
                    }
                </Row>
            </Container>
        </section>
    </div>
  )
}

export default NewShop