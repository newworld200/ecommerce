import React, { useEffect, useState } from 'react'
import NewHeader from './NewHeader'
import useGetData from '../custom-hooks/useGetData'
import { Col, Container, Row } from 'react-bootstrap';
import ProductsList from '../components/ProductList';
// import Header from '../components/Header';

function NewHome() {

  const {data:products} = useGetData('products')

  const [Trending, setTrending] =useState([]);

  useEffect(() => {
    const filteredTrending = products.filter(
      item => item.category === 'sofa'
    );

    setTrending(filteredTrending);
  },[products])

  return (
   
    <div>
        <NewHeader /> 
        {/* <Header /> */}
        <div>
          <Container>
            <Row>
              <Col lg='12' className='text-center'>
                <h2>Trending</h2>
              </Col>
              <ProductsList data={Trending} />
            </Row>
          </Container>
        </div>  
    </div>
  )
}

export default NewHome